package com.demo.service;

import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.demo.model.Greetings;
import com.demo.stream.GreetingsStreams;

@Component
@Slf4j
public class GreetingsListener {
	//
	private static final Logger logger  = LoggerFactory.getLogger(GreetingsListener.class);
    @StreamListener(GreetingsStreams.INPUT)
    public void handleGreetings(@Payload Greetings greetings) {
        System.out.println("Received greetings: {}" + greetings);
        //
        logger.info("Received greetings: {}" + greetings);
    }
}
